
# Physician Router (Vercel-ready)

Multi-stop route planner for physician visits. Sign in with Google (Firebase), select physicians, optimize route with Google Maps, and export to Google Maps link, PDF, and ICS.

## 1) Prereqs
- Node.js 18+
- Firebase project with Authentication (Google) + Firestore + (optional) Storage
- Google Maps JavaScript API key

## 2) Env Vars (Vercel → Settings → Environment Variables)
```
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=
NEXT_PUBLIC_MAPS_API_KEY=
```

## 3) Firestore Rules (basic, require login)
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{doc=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## 4) Local run
```
npm install
npm run dev
```

## 5) Deploy to Vercel (no GitHub)
```
npx vercel
npx vercel --prod
```
Then add your `*.vercel.app` domain to Firebase → Authentication → Authorized Domains.

## Notes
- Geocoding happens in the browser via Google Maps JS Geocoder when you save a physician.
- Route optimization uses DirectionsService with `optimizeWaypoints: true`.
- Export buttons create a Google Maps link, a simple PDF with the stop list, and an ICS calendar.
