
import React from 'react';

type Marker = { lat:number, lng:number, label?:string };

declare global { interface Window { initMap: any } }

function loadScript(src:string){
  return new Promise<void>((resolve,reject)=>{
    const s = document.createElement('script');
    s.src = src;
    s.async = true;
    s.defer = true;
    s.onload = ()=> resolve();
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

export default function Map({ markers, polyline }:{markers:Marker[], polyline?:google.maps.LatLngLiteral[]}){
  const ref = React.useRef<HTMLDivElement>(null);
  const mapRef = React.useRef<google.maps.Map>();

  React.useEffect(()=>{
    (async ()=>{
      if(!ref.current) return;
      if(!(window as any).google){
        const key = process.env.NEXT_PUBLIC_MAPS_API_KEY;
        const src = `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places`;
        await loadScript(src);
      }
      mapRef.current = new google.maps.Map(ref.current, { zoom: 11, center: markers[0] || {lat:31.7619,lng:-106.4850} });
      render();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);

  React.useEffect(()=>{ render(); }, [markers, polyline]);

  const render = ()=>{
    const map = mapRef.current;
    if(!map) return;
    map.setCenter(markers[0] || {lat:31.7619,lng:-106.4850});
    markers.forEach((m, idx)=> new google.maps.Marker({ position: m, label: String(idx+1), map }));
    if(polyline && polyline.length>1){
      new google.maps.Polyline({ path: polyline, map });
    }
    const bounds = new google.maps.LatLngBounds();
    markers.forEach(m=> bounds.extend(m as any));
    if(!bounds.isEmpty()) map.fitBounds(bounds);
  };

  return <div className="w-full h-96 rounded-xl border" ref={ref}/>;
}
