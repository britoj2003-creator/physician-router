
import React from 'react';
import { db } from '../lib/firebase';
import { collection, onSnapshot, deleteDoc, doc } from 'firebase/firestore';

type Physician = {
  id: string;
  name: string;
  address: string;
  lat?: number;
  lng?: number;
  notes?: string;
};

export default function PhysicianList({ onSelect, selectedIds, onEdit }:{
  onSelect: (id:string, checked:boolean)=>void,
  selectedIds: Set<string>,
  onEdit: (p:Physician)=>void
}){
  const [list, setList] = React.useState<Physician[]>([]);
  const [q, setQ] = React.useState('');

  React.useEffect(()=>{
    const unsub = onSnapshot(collection(db,'physicians'), (snap)=>{
      const data: Physician[] = [];
      snap.forEach(d=> data.push({id:d.id, ...(d.data() as any)}));
      data.sort((a,b)=> a.name.localeCompare(b.name));
      setList(data);
    });
    return ()=>unsub();
  },[]);

  const confirmDelete = async (p:Physician)=>{
    if(confirm(`Delete ${p.name}? This cannot be undone.`)){
      await deleteDoc(doc(db,'physicians', p.id));
    }
  };

  const filtered = list.filter(p=> p.name.toLowerCase().includes(q.toLowerCase()) || p.address.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <input placeholder="Search physicians..." value={q} onChange={e=>setQ(e.target.value)}
               className="w-full border rounded-lg px-3 py-2"/>
      </div>
      <ul className="divide-y rounded-xl border">
        {filtered.map(p=> (
          <li key={p.id} className="p-3 flex items-center justify-between">
            <label className="flex items-center gap-3">
              <input type="checkbox" checked={selectedIds.has(p.id)} onChange={e=>onSelect(p.id, e.target.checked)} />
              <div>
                <div className="font-medium">{p.name}</div>
                <div className="text-xs text-gray-500">{p.address}</div>
              </div>
            </label>
            <div className="flex items-center gap-2">
              <button className="text-sm px-3 py-1 rounded-lg bg-gray-100" onClick={()=>onEdit(p)}>Edit</button>
              <button className="text-sm px-3 py-1 rounded-lg bg-red-600 text-white" onClick={()=>confirmDelete(p)}>Delete</button>
            </div>
          </li>
        ))}
        {filtered.length===0 && <li className="p-4 text-gray-500">No physicians found.</li>}
      </ul>
    </div>
  );
}
