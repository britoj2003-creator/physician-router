
export function generateICS(stops: {name: string, address: string, dt: Date}[]): string {
  const pad = (n:number)=> String(n).padStart(2,'0');
  const dtstamp = new Date();
  const fmt = (d:Date)=> d.getUTCFullYear()+
    pad(d.getUTCMonth()+1)+
    pad(d.getUTCDate())+'T'+
    pad(d.getUTCHours())+
    pad(d.getUTCMinutes())+
    pad(d.getUTCSeconds())+'Z';

  let ics = 'BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Physician Router//EN\n';
  stops.forEach((s,i)=>{
    const start = new Date(s.dt);
    const end = new Date(start.getTime()+30*60000);
    ics += 'BEGIN:VEVENT\n';
    ics += 'UID:'+fmt(dtstamp)+'-'+i+'@physician-router\n';
    ics += 'DTSTAMP:'+fmt(dtstamp)+'\n';
    ics += 'DTSTART:'+fmt(start)+'\n';
    ics += 'DTEND:'+fmt(end)+'\n';
    ics += 'SUMMARY:'+s.name+' visit\n';
    ics += 'LOCATION:'+s.address.replace(/,/g,'\\,')+'\n';
    ics += 'END:VEVENT\n';
  });
  ics += 'END:VCALENDAR\n';
  return ics;
}
