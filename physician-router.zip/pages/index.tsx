
import React from 'react';
import AuthGate from '../components/AuthGate';
import PhysicianForm from '../components/PhysicianForm';
import PhysicianList from '../components/PhysicianList';
import RoutePlanner from '../components/RoutePlanner';
import { db } from '../lib/firebase';
import { collection, onSnapshot } from 'firebase/firestore';

type Physician = { id:string; name:string; address:string; lat?:number; lng?:number; notes?:string };

export default function Home(){
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [editing, setEditing] = React.useState<Physician | null>(null);
  const [showForm, setShowForm] = React.useState(false);
  const [list, setList] = React.useState<Physician[]>([]);

  React.useEffect(()=>{
    const unsub = onSnapshot(collection(db,'physicians'), (snap)=>{
      const data: Physician[] = [];
      snap.forEach(d=> data.push({id:d.id, ...(d.data() as any)}));
      setList(data);
    });
    return ()=>unsub();
  },[]);

  const toggle = (id:string, checked:boolean)=>{
    const next = new Set(selected);
    if(checked) next.add(id); else next.delete(id);
    setSelected(next);
  };

  const selectedPhysicians = list.filter(p=> selected.has(p.id));

  return (
    <AuthGate>
      <main className="max-w-6xl mx-auto p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Physician Router</h1>
          <button className="px-4 py-2 rounded-lg bg-black text-white" onClick={()=>{ setEditing(null); setShowForm(true); }}>Add Physician</button>
        </div>

        {showForm && (
          <div className="p-4 rounded-xl border">
            <h2 className="font-medium mb-2">{editing ? 'Edit Physician' : 'Add Physician'}</h2>
            <PhysicianForm existing={editing ?? undefined} onDone={()=>{ setShowForm(false); }}/>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h2 className="font-medium mb-2">Physicians</h2>
            <PhysicianList
              onSelect={toggle}
              selectedIds={selected}
              onEdit={(p)=>{ setEditing(p); setShowForm(true); }}
            />
          </div>
          <div>
            <h2 className="font-medium mb-2">Route Planner</h2>
            <div className="text-sm text-gray-600 mb-2">Select physicians (left) then build an optimized route. Use export buttons to share.</div>
            <RoutePlanner physicians={selectedPhysicians}/>
          </div>
        </div>
      </main>
    </AuthGate>
  );
}
