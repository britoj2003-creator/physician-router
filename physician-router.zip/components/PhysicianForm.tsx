
import React from 'react';
import { db } from '../lib/firebase';
import { collection, addDoc, updateDoc, doc } from 'firebase/firestore';

type Physician = {
  id?: string;
  name: string;
  address: string;
  lat?: number;
  lng?: number;
  notes?: string;
};

export default function PhysicianForm({ existing, onDone }:{existing?:Physician, onDone: ()=>void}){
  const [name,setName] = React.useState(existing?.name ?? '');
  const [address,setAddress] = React.useState(existing?.address ?? '');
  const [notes,setNotes] = React.useState(existing?.notes ?? '');

  const geocode = async () => {
    return new Promise<{lat:number,lng:number}>((resolve,reject)=>{
      // @ts-ignore
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address }, (results:any, status:any)=>{
        if(status==='OK' && results[0]){
          const loc = results[0].geometry.location;
          resolve({lat: loc.lat(), lng: loc.lng()});
        } else {
          reject(status);
        }
      });
    });
  };

  const save = async (e:React.FormEvent)=>{
    e.preventDefault();
    let coords: {lat?:number,lng?:number} = {};
    try { coords = await geocode(); } catch(e){ console.warn('Geocode failed', e); }

    if(existing?.id){
      await updateDoc(doc(db,'physicians', existing.id), { name, address, notes, ...coords });
    } else {
      await addDoc(collection(db,'physicians'), { name, address, notes, ...coords });
    }
    onDone();
  };

  return (
    <form onSubmit={save} className="space-y-3">
      <div>
        <label className="block text-sm text-gray-600">Name</label>
        <input className="w-full border rounded-lg px-3 py-2" value={name} onChange={e=>setName(e.target.value)} required/>
      </div>
      <div>
        <label className="block text-sm text-gray-600">Address</label>
        <input className="w-full border rounded-lg px-3 py-2" value={address} onChange={e=>setAddress(e.target.value)} required/>
      </div>
      <div>
        <label className="block text-sm text-gray-600">Notes</label>
        <textarea className="w-full border rounded-lg px-3 py-2" value={notes} onChange={e=>setNotes(e.target.value)} />
      </div>
      <div className="flex gap-2">
        <button className="px-4 py-2 bg-black text-white rounded-lg">Save</button>
        <button type="button" onClick={onDone} className="px-4 py-2 bg-gray-100 rounded-lg">Cancel</button>
      </div>
    </form>
  );
}
