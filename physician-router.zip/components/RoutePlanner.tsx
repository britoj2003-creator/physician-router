
import React from 'react';
import Map from './Map';
import jsPDF from 'jspdf';
import { generateICS } from '../utils/ics';

type Physician = { id:string; name:string; address:string; lat?:number; lng?:number };

export default function RoutePlanner({ physicians }:{ physicians:Physician[] }){
  const [ordered, setOrdered] = React.useState<Physician[]>([]);
  const [poly, setPoly] = React.useState<google.maps.LatLngLiteral[]>([]);

  const buildRoute = async ()=>{
    const pts = physicians.filter(p=> p.lat && p.lng);
    if(pts.length<2){
      alert('Need at least 2 physicians with geocoded addresses.');
      return;
    }
    // @ts-ignore
    const ds = new google.maps.DirectionsService();
    const origin = { lat: pts[0].lat!, lng: pts[0].lng! };
    const destination = { lat: pts[pts.length-1].lat!, lng: pts[pts.length-1].lng! };
    const waypoints = pts.slice(1, -1).map(p=> ({ location: {lat:p.lat!, lng:p.lng!} }));
    const res = await ds.route({
      origin, destination, waypoints, travelMode: google.maps.TravelMode.DRIVING, optimizeWaypoints: true
    });
    const order = res.routes[0].waypoint_order;
    const orderedList = [pts[0], ...order.map(i=> pts.slice(1,-1)[i]), pts[pts.length-1]];
    setOrdered(orderedList);

    const polyline: google.maps.LatLngLiteral[] = [];
    res.routes[0].legs.forEach(leg=>{
      polyline.push(leg.start_location.toJSON());
      polyline.push(leg.end_location.toJSON());
    });
    setPoly(polyline);
  };

  const exportGoogleMapsLink = ()=>{
    const pts = ordered.length ? ordered : physicians;
    if(pts.length<2){ alert('Build a route first.'); return; }
    const origin = encodeURIComponent(`${pts[0].lat},${pts[0].lng}`);
    const destination = encodeURIComponent(`${pts[pts.length-1].lat},${pts[pts.length-1].lng}`);
    const waypoints = pts.slice(1,-1).map(p=> `${p.lat},${p.lng}`).join('|');
    const url = `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&travelmode=driving&waypoints=${encodeURIComponent(waypoints)}`;
    window.open(url, '_blank');
  };

  const exportPDF = ()=>{
    const pts = ordered.length ? ordered : physicians;
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.text('Physician Route', 14, 18);
    doc.setFontSize(11);
    pts.forEach((p, i)=>{
      doc.text(`${i+1}. ${p.name} - ${p.address}`, 14, 30 + i*8);
    });
    doc.save('route.pdf');
  };

  const exportICS = ()=>{
    const pts = ordered.length ? ordered : physicians;
    const now = new Date();
    const stops = pts.map((p,i)=> ({
      name: p.name,
      address: p.address,
      dt: new Date(now.getTime() + i*45*60000)
    }));
    const ics = generateICS(stops);
    const blob = new Blob([ics], {type:'text/calendar'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'route.ics';
    a.click();
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <button onClick={buildRoute} className="px-4 py-2 bg-black text-white rounded-lg">Build Route (optimize)</button>
        <button onClick={exportGoogleMapsLink} className="px-4 py-2 bg-gray-100 rounded-lg">Open in Google Maps</button>
        <button onClick={exportPDF} className="px-4 py-2 bg-gray-100 rounded-lg">Export PDF</button>
        <button onClick={exportICS} className="px-4 py-2 bg-gray-100 rounded-lg">Export ICS</button>
      </div>
      <Map markers={(ordered.length?ordered:physicians).filter(p=>p.lat&&p.lng).map((p)=>({lat:p.lat!, lng:p.lng!}))} polyline={poly}/>
      {ordered.length>0 && (
        <ol className="list-decimal ml-6">
          {ordered.map((p,i)=>(<li key={p.id}>{p.name} — <span className="text-gray-500">{p.address}</span></li>))}
        </ol>
      )}
    </div>
  );
}
