
import React from 'react';
import { auth, provider } from '../lib/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  if (loading) return <div className="p-6">Loading...</div>;

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="p-8 bg-white rounded-2xl shadow w-full max-w-md text-center">
          <h1 className="text-2xl font-semibold mb-4">Physician Router</h1>
          <p className="text-gray-600 mb-6">Sign in with Google to continue</p>
          <button
            className="px-4 py-2 rounded-xl bg-black text-white hover:opacity-90"
            onClick={() => signInWithPopup(auth, provider)}
          >
            Sign in with Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between px-4 py-2 border-b">
        <div className="font-medium">Signed in as {user.displayName}</div>
        <button className="text-sm px-3 py-1 rounded-lg bg-gray-100 hover:bg-gray-200" onClick={() => signOut(auth)}>
          Sign out
        </button>
      </div>
      {children}
    </div>
  );
}
